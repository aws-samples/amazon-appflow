import boto3
import botocore
import sys
import time

def lambda_handler(event, context):
    client = boto3.client('glue')
    # Run the Glue Crawler
    try:
        client.start_crawler(Name='sfdev-appflow-account')
    except botocore.exceptions.ClientError as e:
        print('{}:{}'.format(e.response['Error']['Code'],e.response['Error']['Message']))
        sys.exit(1)
    
    # Check for Glue crawler completion
    response = client.get_crawler(Name='sfdev-appflow-account')
    status=response['Crawler']['State']
    while status:
        if status == 'READY':
            print('Crawling completed!!')
            break
        else:
            response = client.get_crawler(Name='sfdev-appflow-account')
            status=response['Crawler']['State']
            print('Crawling in progress!! status is {}'.format(status))
            # Sleep to avoid throttling error
            time.sleep(30)
            continue
